package com.example.apppageadjustment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {
/*Allows the user to navigate the home page and records/monitors information through firebase such authentication*/
    EditText registerName,registerEmail,registerPassword,registerPassword2;
    Button reg_submitButton, reg_cancelButton; //Has similar function like C++
    FirebaseAuth fAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);


        //List all ids for items that will be recorded in the database
        registerName =  findViewById(R.id.register_Name)  ;
        registerEmail =  findViewById(R.id.register_Email) ;
        registerPassword = findViewById(R.id.register_Password)  ;
        registerPassword2=  findViewById(R.id.register_Password2) ;

        fAuth = FirebaseAuth.getInstance();


        //Implement submit and cancel buttons so that they can either enter com.example.apppageadjustment.ui.data or go back to the login screen
        //Button clicks are organized below
        reg_submitButton = findViewById(R.id.register_submit);
        reg_submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Extract com.example.apppageadjustment.ui.data
                String fullName = registerName.getText().toString();
                String emailAddress = registerEmail.getText().toString();
                String password = registerPassword.getText().toString();
                String password2 = registerPassword2.getText().toString();
                //Warn the user if the text fields are empty to fill out the following information
                if (fullName.isEmpty()) {
                    registerName.setError("Must Enter a name");
                    return;
                }
                if (emailAddress.isEmpty()) {
                    registerEmail.setError("Must Enter a Email");
                    return;
                }
                if (password.isEmpty()) {
                    registerPassword.setError("Must Enter a Password");
                    return;
                }
                if (password2.isEmpty()) {
                    registerPassword2.setError("Must Enter a Password again");
                    return;
                }

                //Password dont match currently
                if (!password.equals(password2)) {
                    registerPassword2.setError("Passwords do not match, try again");
                } else {
                    //passed, place toast message here to say it passed
                }

                fAuth.createUserWithEmailAndPassword(emailAddress,password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                    //Successful user is at the next page
                        signup();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                       Toast.makeText(Register.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


            }
                //Data has been recorded, enter it into firebase



        });
        //The user no longer wishes to register, click the cancel button
        reg_cancelButton = findViewById(R.id.register_cancel);
        reg_cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            //User will be navigated back to the login page(Login Class)
            public void onClick(View view) {
                backLogin();
            }
        });
    }
        //If sign up was successful then the user will be navigated to the home page
        private void signup() {
            Intent intent = new Intent(this, Login.class);
            Toast.makeText(Register.this, "Signup Successful!", Toast.LENGTH_SHORT).show();
            startActivity(intent);
    }


    //If sign up is activated, the page will open up to prompt the user to register their information
        private void backLogin () {
        //User cancelled register page and will be redirected the login page
            Intent intent = new Intent(this, Login.class);
            Toast.makeText(Register.this, "Signup Cancelled", Toast.LENGTH_SHORT).show();
            startActivity(intent);
        }
    }