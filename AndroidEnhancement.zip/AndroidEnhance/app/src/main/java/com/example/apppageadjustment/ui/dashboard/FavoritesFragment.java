package com.example.apppageadjustment.ui.dashboard;


import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.apppageadjustment.R;
import com.example.apppageadjustment.ui.data.FavAdapter;
import com.example.apppageadjustment.ui.data.FavDB;
import com.example.apppageadjustment.ui.data.FavEvent;

import java.util.ArrayList;
import java.util.List;

public class FavoritesFragment extends Fragment {

    private RecyclerView recyclerView;
    private FavDB favDB;
    private List<FavEvent> favEventList = new ArrayList<>();
    private FavAdapter favAdapter;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_favorites,container,false);

        favDB = new FavDB(getActivity());
        recyclerView = root.findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        loadData();

        return root;
    }

    private void loadData() {
        if (favEventList != null) {
            favEventList.clear();
        }
        SQLiteDatabase db = favDB.getReadableDatabase();
        Cursor cursor = favDB.select_all_favorite_list();
        try{
            while (cursor.moveToNext()){
                String title = cursor.getString(cursor.getColumnIndex(FavDB.EVENT_TITLE));
                String id = cursor.getString(cursor.getColumnIndex(FavDB.KEY_ID));
                int image = Integer.parseInt(cursor.getString(cursor.getColumnIndex(FavDB.EVENT_IMAGE)));
                FavEvent favEvent = new FavEvent(title, id, image);
                favEventList.add(favEvent);

            }
        } finally {
            if (cursor != null && cursor.isClosed())
                cursor.close();
            db.close();
        }

        favAdapter = new FavAdapter(getActivity(), favEventList);
        recyclerView.setAdapter(favAdapter);
    }
}