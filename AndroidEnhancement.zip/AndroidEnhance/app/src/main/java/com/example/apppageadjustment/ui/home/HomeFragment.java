package com.example.apppageadjustment.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.apppageadjustment.ui.data.EventItem;
import com.example.apppageadjustment.ui.data.EventAdapter;
import com.example.apppageadjustment.R;

import java.util.ArrayList;

/*Main page once the user logs in. The user should be able to view all the events that are coded within this location. This will interact with MyAdapter
and datamodel in order to display this information to the user within the fragment_home.xml file.*/
public class HomeFragment extends Fragment{

//Declare variables
    RecyclerView recview;
    ArrayList<EventItem> dataholder;


    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        View view = inflater.inflate(R.layout.fragment_home,container,false);
        recview = (RecyclerView) view.findViewById(R.id.recview);
        recview.setLayoutManager(new LinearLayoutManager(getContext()));
        dataholder = new ArrayList<EventItem>();
//Information that will placed into the array in order to display events to the users in the app
        EventItem ob1 = new EventItem(R.drawable.daughtry,R.drawable.ic_baseline_favorite_border_24,"Daughtry","Sat,Aug 27,7 PM – Sun,Aug 28,12 AM","Mount Airy Casino Resort, PA", "0","0");
        dataholder.add(ob1);

        EventItem ob2 = new EventItem(R.drawable.dreamcatcher,R.drawable.ic_baseline_favorite_border_24,"Dreamcatcher","Fri, Jul 1, 7:00 – 11:30 PM","Santander Arena Penn St,PA", "1","0");
        dataholder.add(ob2);

        EventItem ob3 = new EventItem(R.drawable.askingalexandria,R.drawable.ic_baseline_favorite_border_24,"Asking Alexandria","Sun, June 5, 6:35pm","Agora Theatre, Cleveland, OH", "2","0");
        dataholder.add(ob3);

        EventItem ob4 = new EventItem(R.drawable.colossalconeast,R.drawable.ic_baseline_favorite_border_24,"Colossalcon East","Fri, Sep 9, 1 PM – Sun, Sep 11, 4 PM","Kalahari Resorts Poconos, PA", "3","0");
        dataholder.add(ob4);

        EventItem ob5 = new EventItem(R.drawable.newyorkcomiccon,R.drawable.ic_baseline_favorite_border_24,"New York Comic Con","Thu,Oct 6 - Sun, Oct 9","Javits Center", "4","0");
        dataholder.add(ob5);

        EventItem ob6 = new EventItem(R.drawable.hackathon,R.drawable.ic_baseline_favorite_border_24,"Inclusive Data Hackathon","Fri, June 17, 8:00pm","Online Event", "5","0");
        dataholder.add(ob6);

        EventItem ob7 = new EventItem(R.drawable.sportech,R.drawable.ic_baseline_favorite_border_24,"Sports Tech Hackathon","Fri, Jul 15th – Jul 19th","Online Event", "6","0");
        dataholder.add(ob7);

        EventItem ob8 = new EventItem(R.drawable.inkcar,R.drawable.ic_baseline_favorite_border_24,"Inkcarceration 2022","Fri,July 15 - Sun, Jul 17","Mansfield, OH", "7","0");
        dataholder.add(ob8);


        recview.setAdapter(new EventAdapter(dataholder));

        return view;
    }



    @Override
    public void onDestroyView() {
        super.onDestroyView();
       // binding = null;
    }


}