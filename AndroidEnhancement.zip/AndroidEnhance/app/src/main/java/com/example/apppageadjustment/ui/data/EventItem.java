package com.example.apppageadjustment.ui.data;
//This file gets and sets the variable information to display the events to the user. This will interact with MyAdapter, homefragment, and the fragment_home.xml page
public class EventItem {


//Declare variables
    int image,favorite,imageResource;
    String eventTitle,eventDate,eventLocation,key_id,favStatus;

    public EventItem(){

    }
//Implement a constructor
    public EventItem(int image, int favorite, String eventTitle, String eventDate, String eventLocation, String key_id, String favStatus){
        this.image = image;
        this.eventTitle = eventTitle;
        this.eventDate = eventDate;
        this.eventLocation = eventLocation;
        this.favorite = favorite;
        this.key_id = key_id;
        this.favStatus = favStatus;
    }
//Implement getter and setters for the imageview and textview variables
    public String getEventTitle() {
        return eventTitle;
    }

    public void setEventTitle(String eventTitle) {
        this.eventTitle = eventTitle;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getEventLocation() {
        return eventLocation;
    }

    public void setEventLocation(String eventLocation) {
        this.eventLocation = eventLocation;
    }

    public int getimage() {

        return image;
    }

    public void setimage(int image) {

        this.image = image;
    }

    public int getfavorite() {

        return favorite;
    }

    public void setfavorite(int favorite) {

        this.favorite = favorite;
    }
//Implemented for favorites page information collection, does not collect at this time
    public String getKey_id() {

        return key_id;
    }

    public void setKey_id(String key_id) {

        this.key_id = key_id;
    }

    public String getFavStatus() {

        return favStatus;
    }

    public void setFavStatus(String favStatus) {

        this.favStatus = favStatus;
    }




}
