package com.example.apppageadjustment.ui.data;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.apppageadjustment.R;

import java.util.ArrayList;
//Adapter used to call and hold information for the events that are implemented into the app and displayed to the user

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.myviewholder>
{
    ArrayList<EventItem> dataholder;
    public EventAdapter(ArrayList<EventItem> dataholder) {
        this.dataholder = dataholder;
    }


    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.events, parent, false);
        return new myviewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myviewholder holder, int position)
    {
        holder.Title.setText(dataholder.get(position).getEventTitle());
        holder.Location.setText(dataholder.get(position).getEventDate());
        holder.Date.setText(dataholder.get(position).getEventLocation());
        holder.Image.setImageResource(dataholder.get(position).getimage());

    }

    @Override
    public int getItemCount() {
        return dataholder.size();
    }

    class myviewholder extends RecyclerView.ViewHolder
    {
        ImageView Image;
        TextView Title, Location, Date;
        Button favBtn;

        public myviewholder(@NonNull View itemView)
        {
            super(itemView);
            Title = itemView.findViewById(R.id.eventTitle);
            Location = itemView.findViewById(R.id.eventLocation);
            Date = itemView.findViewById(R.id.eventTime);
            Image = itemView.findViewById(R.id.imageView);


        }
    }
}

