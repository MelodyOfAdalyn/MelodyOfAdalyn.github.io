package com.example.apppageadjustment.ui.data;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.apppageadjustment.R;

import java.util.List;

public class FavAdapter extends RecyclerView.Adapter<FavAdapter.ViewHolder> {
    private Context context;
    private List<FavEvent> favEventList;
    private FavDB favDB;

    public FavAdapter(Context context, List<FavEvent> favEventList) {
        this.context = context;
        this.favEventList = favEventList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fav_event,parent,false);
        favDB = new FavDB(context);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.favTextView.setText(favEventList.get(position).getItem_title());
        holder.favImageView.setImageResource(favEventList.get(position).getItem_image());
    }

    @Override
    public int getItemCount() {
        return favEventList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView favTextView;
        Button favBtn;
        ImageView favImageView;

        public ViewHolder(@NonNull View itemView){
            super(itemView);
            favTextView = itemView.findViewById(R.id.favTextView);
            favBtn = itemView.findViewById(R.id.favBtn);
            favImageView = itemView.findViewById(R.id.favImageView);

            favBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    final FavEvent favEvent = favEventList.get(position);
                    favDB.remove_fav(favEvent.getKey_id());
                    removeItem(position);
                }
            });
        }
    }

    private void removeItem(int position) {
        favEventList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, favEventList.size());

    }

}
