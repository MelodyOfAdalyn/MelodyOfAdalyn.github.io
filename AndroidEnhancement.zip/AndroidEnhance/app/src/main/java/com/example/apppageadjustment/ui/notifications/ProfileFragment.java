package com.example.apppageadjustment.ui.notifications;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.apppageadjustment.Login;
import com.example.apppageadjustment.R;
import com.example.apppageadjustment.Register;
import com.example.apppageadjustment.databinding.FragmentProfileBinding;
import com.google.firebase.auth.FirebaseAuth;


//Profile page includes tabs general settings and profile information along with the logout button of the app
//If logout is pressed this should direct the user back to the login page
//As of right now the tabs for settings and profile information are only for display and cannot navigate from page to page
public class ProfileFragment extends Fragment {
    Button logoutBtn;
    private FragmentProfileBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ProfileViewModel profileViewModel =
                new ViewModelProvider(this).get(ProfileViewModel.class);
        //Implement log out figure with firebase information
        View v = inflater.inflate(R.layout.fragment_profile,container, false);

        logoutBtn = v.findViewById(R.id.signoff_btn);


        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(getActivity(), Login.class);
                startActivity(intent);
            }

        });


        return v;


    }














    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}